# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CAMIS Qgis
                                 A QGIS plugin
 CAMIS Qgis Version
                              -------------------
        begin                : 2026-04-01
        git sha              : $Format:%H$
        copyright            : (C) 2026 by Yitagesu
        email                : yitekeyman@gmail.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from PyQt5.QtCore import QSettings, QTranslator, QCoreApplication, Qt, QUrl
from PyQt5.QtWidgets import QAction, QApplication, QWidget, QMessageBox
from PyQt5.QtNetwork import QNetworkRequest

try:
    from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage, QWebEngineSettings
    USING_WEBENGINE = True
except ImportError:
    # Fallback for older setups (unlikely in QGIS 3.40)
    from PyQt5.QtWebKitWidgets import QWebView, QWebPage
    from PyQt5.QtWebKit import QWebSettings
    USING_WEBENGINE = False


from qgis.core import *
from qgis.PyQt.QtGui import QIcon
from qgis.utils import iface

import configparser
import json
import os.path

from . import resources
from .cmss_task_manager_dockwidget import CMSS2DockWidget
import requests

from .CMSSURLProcessor import CMSSURLProcessor
from .CMSSLoginForm import CMSSLoginForm

if USING_WEBENGINE:
    class CMSSWebPage(QWebEnginePage):
        def __init__(self, cmss, parent=None):
            super(CMSSWebPage, self).__init__(parent)
            self.cmss = cmss
            self.urlProcessor = CMSSURLProcessor(self.cmss, self)
        
        def unload(self):
            self.urlProcessor.unload()
        
        def acceptNavigationRequest(self, url, type, isMainFrame):
            if self.urlProcessor.processURL(url.path(), self.cmss.decodeQuery(url)):
                return False
            return True
else:
    class CMSSWebPage(QWebPage):
        def __init__(self, cmss, parent=None):
            super(CMSSWebPage, self).__init__(parent)
            self.setLinkDelegationPolicy(QWebPage.DelegateExternalLinks)
            self.cmss = cmss
            self.urlProcessor = CMSSURLProcessor(self.cmss, self)
        
        def unload(self):
            self.urlProcessor.unload()
            return
        
        def acceptNavigationRequest(self, frame, request, type):
            if self.urlProcessor.processURL(request.url().path(), self.cmss.decodeQuery(request.url())):
                return False
            return True

class CMSS2:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)

        #load configuration
        self.readConfig()

        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'CMSS2_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)

            if qVersion() > '4.3.3':
                QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.menu = self.tr(u'&CAMIS-v2 Qgis')
        # TODO: We are going to let the user set this up in a future iteration
        self.toolbar = self.iface.addToolBar(u'CAMIS-v2 Qgis')
        self.toolbar.setObjectName(u'CAMIS-v2 Qgis')

        #print("** INITIALIZING CAMIS Qgis")

        self.pluginIsActive = False
        self.dockwidget = None
        self.sessionid = None
        self.page = None
        self.logedIn = False

        self.map_layers = []

        # Store references to the login/logout actions for dynamic visibility
        self.login_action = None
        self.logout_action = None

    # Python 3 compatible decodeQuery method
    def decodeQuery(self, url):
        """Decode URL query parameters."""
        # Handle both QUrl and string input
        if isinstance(url, str):
            # If it's already a string, parse it directly
            if '?' in url:
                query_str = url.split('?')[1]
            else:
                return {}
        else:
            # QUrl object
            query_str = url.query()
        
        # Parse query string
        result = {}
        if query_str:
            for pair in query_str.split('&'):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    # Use proper URL decoding
                    from urllib.parse import unquote
                    result[key] = unquote(value)
        return result

    def showCriticalMessage(self, title, msg):
        # Proper QMessageBox usage
        QMessageBox.critical(None, title, msg)

    def showWarningMessage(self, msg):
        # Proper QMessageBox usage
        QMessageBox.warning(None, 'MASSREG', msg)

    def showUserConfirmation(self, msg):
        # Proper QMessageBox usage
        reply = QMessageBox.question(None, 'CAMIS-v2', msg, 
                                     QMessageBox.Yes | QMessageBox.No)
        return reply == QMessageBox.Yes

    def showInformationMessage(self, title, msg):
        # Proper QMessageBox usage
        QMessageBox.information(None, title, msg)

    # Python 3 compatible readConfig method
    def readConfig(self):
        """Read configuration from JSON file."""
        config_path = os.path.join(self.plugin_dir, 'camis_qgis.json')
        # Use context manager for file handling
        with open(config_path, 'r', encoding='utf-8') as f:
            jstr = f.read()
        config = json.loads(jstr)
        print(str(jstr))  # Added parentheses
        self.db_host = config['db-host']
        self.db_port = config['db-port']
        self.http_server = config['http']

    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('CAMIS-v2 Qgis', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = self.plugin_dir + '/camis_cmss_login.png'
        self.login_action = self.add_action(
            icon_path,
            text=self.tr(u'CAMIS-v2 Login'),
            callback=self.loginAndRun,
            parent=self.iface.mainWindow())
        
        icon_path = self.plugin_dir + '/camis_cmss_logout.png'
        self.logout_action = self.add_action(
            icon_path,
            text='CAMIS-v2 Logout',
            callback=self.logout,
            parent=self.iface.mainWindow())
        
        # Initially hide the logout button, show login button
        self.logout_action.setVisible(False)
        
        self.add_geometryActions()
        
    #--------------------------------------------------------------------------
    def logout(self):
        if not(self.logedIn):
            self.showCriticalMessage('CAMIS-v2 Qgis', 'You are not logged in')
            return
        if not(self.showUserConfirmation('Are you sure you want to logout?')):
            return

        try:
            self.invokeServer('/api/admin/logout?sid=' + self.sid, {})
        except Exception as ex:
            self.showWarningMessage('Error trying to close the server session.\nThe server may be down')

        self.deactivatePlugin()
        self.logedIn = False
        
        # Update button visibility: show login, hide logout
        self.login_action.setVisible(True)
        self.logout_action.setVisible(False)

    def add_geometryActions(self):
        self.toolbar.addSeparator()
        self.toolbar.addAction(self.iface.actionAddFeature())
        self.toolbar.addAction(self.iface.actionVertexTool())
        self.toolbar.addAction(self.iface.actionDeleteSelected())
        self.toolbar.addAction(self.iface.actionSplitFeatures())

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""

        #print("** CLOSING CAMIS Qgis")

        # disconnects
        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)

        # remove this statement if dockwidget is to remain
        # for reuse if plugin is reopened
        # Commented next statement since it causes QGIS crashe
        # when closing the docked window:
        # self.dockwidget = None
        self.pluginIsActive = False

    # Python 3 compatible invokeServer method
    def invokeServer(self, cmd, data):
        url = self.http_server + cmd
        print(str(url))
        r = None
        if data is None:
            if self.sessionid:
                r = requests.get(url, cookies={'.ASPNetCoreSession': self.sessionid})
            else:
                r = requests.get(url)
        else:
            print(str(data))
            headers = {'Content-type': 'application/json'}
            if self.sessionid:
                r = requests.post(url, data=json.dumps(data), 
                                 cookies={'.ASPNetCoreSession': self.sessionid}, 
                                 headers=headers)
            else:
                r = requests.post(url, data=json.dumps(data), headers=headers)
        if '.ASPNetCoreSession' in r.cookies.keys():
            self.sessionid = r.cookies['.ASPNetCoreSession']
        res = r.json()
        if r.status_code != 200:
            res['error'] = res['message']
        else:
            res['error'] = None
        print(str(res))

        return res

    def deactivatePlugin(self):
        if self.page:
            self.page.unload()
            self.page = None
        if self.dockwidget:
            self.iface.removeDockWidget(self.dockwidget)
            self.dockwidget = None
        self.unloadCMSSLayers()

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        #print("** UNLOAD CAMIS Qgis")
        self.deactivatePlugin()

        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&CAMIS-v2 Qgis'),
                action)
            self.iface.removeToolBarIcon(action)
        # remove the toolbar
        if self.toolbar:
            del self.toolbar

    #--------------------------------------------------------------------------

    # Updated for Qt5 WebEngine/WebKit
    def fixBrowserSetting(self):
        if USING_WEBENGINE:
            settings = self.page.settings()
            settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
            settings.setAttribute(QWebEngineSettings.JavascriptCanOpenWindows, True)
            settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
            settings.setAttribute(QWebEngineSettings.LocalContentCanAccessRemoteUrls, True)
            settings.setAttribute(QWebEngineSettings.LocalContentCanAccessFileUrls, True)
        else:
            self.page.settings().setAttribute(QWebSettings.JavascriptEnabled, True)
            self.page.settings().setAttribute(QWebSettings.JavascriptCanOpenWindows, True)
            self.page.settings().setAttribute(QWebSettings.JavascriptCanCloseWindows, True)
            self.page.settings().setAttribute(QWebSettings.JavascriptCanAccessClipboard, True)
            self.page.settings().setAttribute(QWebSettings.DeveloperExtrasEnabled, True)
            self.page.settings().setAttribute(QWebSettings.OfflineStorageDatabaseEnabled, True)
            self.page.settings().setAttribute(QWebSettings.OfflineWebApplicationCacheEnabled, True)
            self.page.settings().setAttribute(QWebSettings.LocalStorageEnabled, True)
            self.page.settings().setAttribute(QWebSettings.LocalStorageDatabaseEnabled, True)
            self.page.settings().setAttribute(QWebSettings.LocalContentCanAccessRemoteUrls, True)
            self.page.settings().setAttribute(QWebSettings.LocalContentCanAccessFileUrls, True)

    # Updated for Qt5 WebEngine/WebKit
    def initBrowser(self):
        if USING_WEBENGINE:
            self.view = QWebEngineView()
            self.page = CMSSWebPage(self)
            self.fixBrowserSetting()
            self.view.setPage(self.page)
            self.view.setUrl(QUrl(self.http_server + '/api/cmss/home?sid=' + self.sid))
        else:
            self.view = QWebView()
            self.page = CMSSWebPage(self)
            self.fixBrowserSetting()
            u = QUrl(self.http_server + '/api/cmss/home?sid=' + self.sid)
            self.page.currentFrame().setUrl(u)
            self.view.setPage(self.page)
        
        self.dockwidget.widget().layout().addWidget(self.view)

    def afterLogin(self):
        self.logedIn = True
        # Update button visibility: hide login, show logout
        self.login_action.setVisible(False)
        self.logout_action.setVisible(True)
        self.run()

    def loginAndRun(self):
        if self.logedIn:
            self.showCriticalMessage('CAMIS-v2 Qgis', 'You have already logged in, please logout first')
            return
        self.loginForm = CMSSLoginForm(self, self.afterLogin)
        self.loginForm.show()

    # Updated for QGIS 3.x API (QgsProject instead of QgsMapLayerRegistry)
    def loadLayer(self, name, style, uri, schema, table, field, key):
        uri.setDataSource(schema, table, field, "", key)
        layer = QgsVectorLayer(uri.uri(False), name, "postgres")
        if style:
            style_path = os.path.join(os.path.dirname(__file__), style)
            layer.loadNamedStyle(style_path)
        # QGIS 3.x uses QgsProject.instance().addMapLayer()
        QgsProject.instance().addMapLayer(layer)
        self.map_layers.append(layer)
        return layer
        
    def loadCMSSLayers(self):
        uri = QgsDataSourceUri()
        uri.setConnection(self.db_host, self.db_port, "nrlais", "user_cmss", "cmssUserPW")
        camis_uri = QgsDataSourceUri()
        camis_uri.setConnection(self.db_host, self.db_port, "camis", "postgres", "admin")

        uri.setDatabase("nrlais")
        uri.setUsername("user_cmss")
        uri.setPassword("cmssUserPW")

        self.loadLayer("Region Boundary", 'region.qml', uri, "nrlais_sys", "t_regions", "geometry", "id")
        self.loadLayer("Woreda Boundary", 'zone.qml', uri, "nrlais_sys", "t_zones", "geometry", "id")
        self.loadLayer("Zone Boundary", 'woreda.qml', uri, "nrlais_sys", "t_woredas", "geometry", "id")
        self.kebele_layer = self.loadLayer("Kebele Boundary", 'kebele.qml', uri, "nrlais_sys", "t_kebeles", "geometry", "id")
        #self.loadLayer("NRLAIS Parcels", "parcel.qml", uri, "nrlais_inventory", "t_parcels", "geometry", "uid")
        self.loadLayer("Land Bank", "landbank.qml", camis_uri, "lb", "land_upin", "geometry", "upin")

    # Updated for QGIS 3.x API
    def unloadCMSSLayers(self):
        # QGIS 3.x uses QgsProject.instance().removeMapLayer()
        for l in self.map_layers:
            QgsProject.instance().removeMapLayer(l.id())
        self.map_layers = []

    def initSnapping(self):
        project = QgsProject.instance()
        project.writeEntry('Digitizing', 'DefaultSnapType', 'to vertex and segment')
        project.writeEntry('Digitizing', 'DefaultSnapTolerance', 3)
        project.writeEntry('Digitizing', 'SnappingMode', 'All visible layers')
        project.writeEntry('Digitizing', 'TopologicalEditing', 1)
        project.writeEntry('Digitizing', 'IntersectionSnapping', True)

    def run(self):
        """Run method that loads and starts the plugin"""

        #print("** STARTING CAMIS Qgis")

        # dockwidget may not exist if:
        #    first run of plugin
        #    removed on close (see self.onClosePlugin method)
        if self.dockwidget == None:
            # Create the dockwidget (after translation) and keep reference
            self.dockwidget = CMSS2DockWidget()
            self.initBrowser()
        else:
            self.dockwidget.show()

        # connect to provide cleanup on closing of dockwidget
        self.dockwidget.closingPlugin.connect(self.onClosePlugin)

        # show the dockwidget
        # TODO: fix to allow choice of dock location
        self.iface.addDockWidget(Qt.RightDockWidgetArea, self.dockwidget)
        self.dockwidget.show()

        #load layers
        self.loadCMSSLayers()
        self.initSnapping()